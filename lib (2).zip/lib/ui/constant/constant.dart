class Constants {
  static const String imageBaseUrl = 'https://image.tmdb.org/t/p';
  static const String imageBaseUrl500 = 'https://image.tmdb.org/t/p/w500';
}