import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cinema_app/ui/constant/color_pallete.dart';
import 'package:cinema_app/ui/screen/user/cubit/user_cubit.dart';
import 'package:cinema_app/ui/screen/login/login_screen.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorPallete.colorPrimary,
      appBar: AppBar(
        backgroundColor: ColorPallete.colorPrimary,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'My Profile',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        actions: [
          Icon(Icons.settings, color: Colors.white),
        ],
      ),
      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 25, horizontal: 10),
            child: BlocBuilder<UserCubit, UserState>(
              builder: (context, state) {
                if (state is UserLoaded) {
                  return Column(
                    children: [
                      CircleAvatar(
                        radius: 60,
                        backgroundImage: NetworkImage('${state.data.image}'),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '${state.data.firstName} ${state.data.lastName}',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                      Text(
                        '${state.data.email}',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 30),
                      _buildProfileOption(Icons.favorite_border, 'Favourites'),
                      _buildProfileOption(Icons.file_download_outlined, 'Downloads'),
                      _buildProfileOption(Icons.language, 'Languages'),
                      _buildProfileOption(Icons.location_on, 'Location'),
                      _buildProfileOption(Icons.subscriptions_outlined, 'Subscriptions'),
                      _buildProfileOption(Icons.monitor_rounded, 'Display'),
                      _buildProfileOption(Icons.restore_from_trash_outlined, 'Clear Cache'),
                      _buildProfileOption(Icons.history_toggle_off_outlined, 'Clear History'),
                      _buildLogoutOption(context),
                    ],
                  );
                } else if (state is UserFailed) {
                  return Center(
                    child: Text(
                      state.message,
                      style: const TextStyle(color: Colors.white),
                    ),
                  );
                } else {
                  return const Center(child: CircularProgressIndicator());
                }
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileOption(IconData icon, String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Icon(icon, color: Colors.white),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
              ),
            ),
          ),
          Icon(Icons.arrow_forward_ios, color: Colors.white),
        ],
      ),
    );
  }

  Widget _buildLogoutOption(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: GestureDetector(
        onTap: () {
          PersistentNavBarNavigator.pushNewScreen(
            context,
            screen: LoginScreen(),
            withNavBar: false,
            pageTransitionAnimation: PageTransitionAnimation.cupertino,
          );
        },
        child: Row(
          children: [
            Icon(Icons.logout_outlined, color: Colors.red),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'Log out',
                style: TextStyle(color: Colors.red, fontSize: 16),
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: Colors.red),
          ],
        ),
      ),
    );
  }
}