import 'package:cinema_app/ui/constant/color_pallete.dart';
import 'package:cinema_app/ui/constant/constant.dart';
import 'package:cinema_app/ui/screen/detail/cubit/detail_movie_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class DetailMovieScreen extends StatelessWidget {
  const DetailMovieScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorPallete.colorPrimary,
      body: BlocBuilder<DetailMovieCubit, DetailMovieState>(
        builder: (context, state) {
        if(state is DetailMovieLoaded){
            return SingleChildScrollView(
              child: Column(
                children: [
                  Stack(
                    children: [
                      Image.network(
                        '${Constant.imageBaseUrl}${'/original'}${state.data.posterPath}',
                        width: double.infinity,
                        height: 500,
                        fit: BoxFit.cover,
                      ),
                      Container(
                        width: double.infinity,
                        height: 500,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.7)
                            ]
                          )
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          vertical: 24.0, horizontal: 16.0
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              onPressed: (){
                                Navigator.pop(context);
                              }, 
                              icon: Icon(
                                Icons.cancel_outlined,
                                color: Colors.white,
                              )
                            ),
                            IconButton(
                              onPressed: (){
                                Navigator.pop(context);
                              }, 
                              icon: Icon(
                                Icons.bookmark,
                                color: Colors.white,
                              )
                            )
                          ],
                        ),
                        
                      ),
                      SizedBox(height: 20,),
                      Stack(
                        children: [
                          Padding(
                            padding: EdgeInsets.symmetric(
                              vertical: 150, horizontal: 50.0
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                IconButton(
                                  onPressed: (){}, 
                                  icon: Icon(
                                    Icons.play_arrow,
                                    size: 100,
                                    color: Colors.grey.shade500,
                                  )
                                )
                              ],
                            ),
                          )
                        ],
                      )
                      
                    ],
                  ),
                  Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.star, 
                        color: ColorPallete.colorOrange,
                      ),
                      Text(
                        '${state.data.voteAverage}/10',
                        style: TextStyle(
                          color: ColorPallete.colorOrange,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        ' (${state.data.voteCount} Voters)',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                        ),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 10),
                  child: Text(
                    '${state.data.title}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 30
                    ),
                  ),
                ),
                
                // SizedBox(
                //   height: 31,
                //   child: ListView.separated(
                //     itemCount: state.data.genres!.length,
                //     scrollDirection: Axis.horizontal,
                //     shrinkWrap: true,
                //     separatorBuilder: (context, index) => const SizedBox(
                //           width: 10,
                //         ),
                //     itemBuilder: (context, index) {
                //       var namaCategories = state.data.genres;
                //       return Container(
                //         padding: const EdgeInsets.symmetric(
                //             horizontal: 31, vertical: 5),
                //         decoration: BoxDecoration(
                //             borderRadius: BorderRadius.circular(90),
                //             color: ColorPallete.colorDarkGrey),
                //         child: Center(
                //           child: Text(
                //             '${state.data.genres?[index]}',
                //             style: TextStyle(color: ColorPallete.colorSecondary),
                //           ),
                //         ),
                //       );
                //     },
                //   ),
                // ),
              
                // Padding(
                //   padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 10),
                //   child: Text(
                //     '${state.data.overview}',
                //     style: const TextStyle(
                //       color: Colors.white,
                //       fontSize: 12,
                //     ),
                //   ),
                // ),
                // FloatingActionButton(
                //   onPressed: () {},
                //   child: Container(
                //     padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 3),
                //     decoration: BoxDecoration(
                //       borderRadius: BorderRadius.circular(60),
                //       color: ColorPallete.colorOrange,
                //     ),
                //     child: Text(
                //       'Get Reservation',
                //       style: TextStyle(
                //         color: Colors.white
                //       ),
                //     ),
                //   ),
                // ),
              ],
                        ),
            );

            

          }else if(state is DetailMovieFailed){
            return Center(
              child: Text(
                state.message,
                style: const TextStyle(color: Colors.white),
              ),
            );
          }else{
            return const Center(
              child: CircularProgressIndicator(),
            );
          }     
        },
    ),
);
}
}

