import 'package:flutter/material.dart';
import 'package:cinema_app/ui/constant/color_pallete.dart';
import 'package:cinema_app/ui/screen/home/home_page.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';

class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Initialize PersistentTabController
    PersistentTabController _controller = PersistentTabController(initialIndex: 0);

    // Build the screens for the bottom navigation bar
    List<Widget> _buildScreens() {
      return [
        HomePage(),
        SizedBox(),  // Empty screen for placeholder
        SizedBox(),  // Empty screen for placeholder
        SizedBox(),  // Empty screen for placeholder
      ];
    }

    // Build the items for the bottom navigation bar
    List<PersistentBottomNavBarItem> _navBarItems() {
      return [
        PersistentBottomNavBarItem(
          icon: Image.asset('assets/images/movie.png'),
          title: 'Movie',
          textStyle: TextStyle(
            color: ColorPallete.colorSecondary,
          ),
          activeColorPrimary: ColorPallete.colorOrange,
          activeColorSecondary: ColorPallete.colorSecondary,
          inactiveColorPrimary: ColorPallete.colorSecondary,
        ),
        PersistentBottomNavBarItem(
          icon: Image.asset('assets/images/ticket.png'),
          title: 'Tickets',
          textStyle: TextStyle(
            color: ColorPallete.colorSecondary,
          ),
          activeColorPrimary: ColorPallete.colorOrange,
          activeColorSecondary: ColorPallete.colorSecondary,
          inactiveColorPrimary: ColorPallete.colorSecondary,
        ),
        PersistentBottomNavBarItem(
          icon: Image.asset('assets/images/bookmark.png'),
          title: 'Bookmark',
          textStyle: TextStyle(
            color: ColorPallete.colorSecondary,
          ),
          activeColorPrimary: ColorPallete.colorOrange,
          activeColorSecondary: ColorPallete.colorSecondary,
          inactiveColorPrimary: ColorPallete.colorSecondary,
        ),
        PersistentBottomNavBarItem(
          icon: Image.asset('assets/images/profile.png'),
          title: 'Profile',
          textStyle: TextStyle(
            color: ColorPallete.colorSecondary,
          ),
          activeColorPrimary: ColorPallete.colorOrange,
          activeColorSecondary: ColorPallete.colorSecondary,
          inactiveColorPrimary: ColorPallete.colorSecondary,
        ),
      ];
    }

    return PersistentTabView(
      context,
      controller: _controller,
      screens: _buildScreens(),
      items: _navBarItems(),
      handleAndroidBackButtonPress: true,
      resizeToAvoidBottomInset: true,
      stateManagement: true,
      hideNavigationBarWhenKeyboardAppears: true,
      padding: const EdgeInsets.all(2),
      isVisible: true,
      animationSettings: const NavBarAnimationSettings(
        navBarItemAnimation: ItemAnimationSettings(
          duration: Duration(milliseconds: 400),
          curve: Curves.ease,
        ),
        screenTransitionAnimation: ScreenTransitionAnimationSettings(
          animateTabTransition: true,
          duration: Duration(milliseconds: 300),
          screenTransitionAnimationType: ScreenTransitionAnimationType.fadeIn,
        ),
        onNavBarHideAnimation: OnHideAnimationSettings(
          duration: Duration(milliseconds: 100),
          curve: Curves.bounceInOut,
        ),
      ),
      navBarHeight: kBottomNavigationBarHeight,
      decoration: NavBarDecoration(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
        // Uncomment to use the backdrop filter
        // colorBehindNavBar: ColorPallete.colorPrimary,
        useBackdropFilter: true,
      ),
      confineToSafeArea: true,
      backgroundColor: ColorPallete.colorGrey,
      navBarStyle: NavBarStyle.style7,
    );
  }
}
