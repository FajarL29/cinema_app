import 'package:cinema_app/ui/constant/color_pallete.dart';
import 'package:cinema_app/ui/screen/home/section/categories/categories.dart';
import 'package:cinema_app/ui/screen/home/section/now_playing/now_playing.dart';
import 'package:cinema_app/ui/screen/home/section/upcoming/upcoming.dart';
import 'package:flutter/material.dart';
// import 'package:cinema_app/ui/screen/home/section/categories/categories.dart';
// import 'package:cinema_app/ui/constant/color_pallete.dart';
// import 'package:cinema_app/ui/screen/home/section/now_playing/now_playing.dart';
// import 'package:cinema_app/ui/screen/home/section/upcoming/upcoming.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<String> categories = ['Action', 'Comedy', 'Horror', 'Romance'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorPallete.colorPrimary,
      body: SingleChildScrollView(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(17.0),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Welcome Fajar',
                            style: TextStyle(
                              color: ColorPallete.colorGrey,
                              fontSize: 16.0,
                            ),
                          ),
                          Text(
                            "Let's relax and watch a movie!",
                            style: TextStyle(
                              color: ColorPallete.colorSecondary,
                              fontWeight: FontWeight.bold,
                              fontSize: 22.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(60),
                      child: Image.asset(
                        'assets/images/killua.png',
                        width: 45,
                        height: 45,
                        fit: BoxFit.fill,
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 48,
                ),
                TextField(
                  style: TextStyle(color: ColorPallete.colorGrey),
                  decoration: InputDecoration(
                    hintText: 'Search a movie....',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(90),
                      borderSide: BorderSide(
                        width: 1, color: ColorPallete.colorDarkGrey
                      ),
                    ),
                    contentPadding: const EdgeInsets.symmetric(vertical: 20),
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: ColorPallete.colorDarkGrey,
                    prefixIconColor: ColorPallete.colorGrey,
                    hintStyle: TextStyle(
                      color: ColorPallete.colorGrey
                    ),
                  ),
                ),
                const SizedBox(
                  height: 28,
                ),
                const CategoriesSection(),
                const NowPlayingSection(),
                const UpcomingSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}