import 'package:flutter/material.dart';

class ColorPallete {
  ColorPallete._();

  static Color colorPrimary = const Color(0xFF000000);
  static Color colorSecondary = const Color(0xFFFFFFFF);
  static Color colorOrange = const Color(0xFFFF5624);
  static Color colorDarkGrey = const Color(0xFF404040);
  static Color colorGrey = const Color(0xFF958E84);
}