class Constant {
  static const String imageBaseUrl = 'https://image.tmdb.org/t/p';
}